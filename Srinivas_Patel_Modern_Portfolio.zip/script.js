const menu = document.querySelector(".menu-toggle");
const nav = document.querySelector("nav");
const top = document.getElementById("top");

menu.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menu.setAttribute("aria-expanded", open);
});

document.querySelectorAll("nav a").forEach(a => {
  a.addEventListener("click", () => {
    nav.classList.remove("open");
    menu.setAttribute("aria-expanded", "false");
  });
});

window.addEventListener("scroll", () => {
  top.classList.toggle("show", window.scrollY > 500);

  const sections = [...document.querySelectorAll("section[id]")];
  const links = [...document.querySelectorAll("nav a")];
  const current = sections.reverse().find(s => window.scrollY >= s.offsetTop - 160);

  links.forEach(link => {
    link.classList.toggle("active", current && link.getAttribute("href") === "#" + current.id);
  });
});

top.addEventListener("click", () => window.scrollTo({top: 0, behavior: "smooth"}));

document.getElementById("year").textContent = new Date().getFullYear();
